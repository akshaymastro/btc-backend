export class LoginDTO {
  name: string;
  password: string;
  message: any;
}
